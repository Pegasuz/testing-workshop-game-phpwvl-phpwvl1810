#!/bin/sh

set -e

# install packages
apt update
apt install -y locales-all php-bcmath php-amqp

apt clean -y

rm -rf /usr/share/man/man1/
#!/usr/bin/env sh

IMAGE_TAG='pegasuz/scraper-php:latest'

docker build -t ${IMAGE_TAG} php --pull